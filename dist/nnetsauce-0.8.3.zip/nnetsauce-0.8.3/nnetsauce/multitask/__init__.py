from .multitaskClassifier import MultitaskClassifier

__all__ = ["MultitaskClassifier"]
