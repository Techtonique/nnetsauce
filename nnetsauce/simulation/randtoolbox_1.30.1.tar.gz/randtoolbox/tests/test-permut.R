library(randtoolbox)

permut(3)
permut(4)
